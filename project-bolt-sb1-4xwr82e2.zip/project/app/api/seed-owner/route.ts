import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'

export async function POST() {
  try {
    const email = 'owner@mindmoney.com'
    const password = 'SenhaFort3#'
    const hashedPassword = await bcrypt.hash(password, 10)
    
    // Check if owner already exists
    const existingOwner = await prisma.user.findUnique({
      where: { email }
    })

    if (existingOwner) {
      return NextResponse.json({
        message: 'OWNER já existe',
        email,
        password: 'SenhaFort3#'
      })
    }

    // Create OWNER user
    const owner = await prisma.user.create({
      data: {
        name: 'MindMoney Owner',
        email,
        phone: '(11) 98167-9795',
        password: hashedPassword,
        role: 'OWNER'
      }
    })

    return NextResponse.json({
      message: 'OWNER criado com sucesso!',
      email,
      password: 'SenhaFort3#',
      userId: owner.id
    })
  } catch (error) {
    console.error('Erro ao criar OWNER:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}

export async function GET() {
  return POST()
}