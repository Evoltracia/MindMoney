import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
    }

    const financialData = await prisma.financialData.findUnique({
      where: { userId: session.user.id }
    })

    const transactions = await prisma.transaction.findMany({
      where: { userId: session.user.id },
      orderBy: { date: 'desc' }
    })

    const challengeProgress = await prisma.challengeProgress.findUnique({
      where: { userId: session.user.id }
    })

    return NextResponse.json({
      financialData,
      transactions,
      challengeProgress
    })
  } catch (error) {
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
    }

    const {
      monthlyIncome,
      monthlyExpenses,
      creditCardDebt,
      loanDebt,
      overdraftDebt
    } = await req.json()

    const financialData = await prisma.financialData.upsert({
      where: { userId: session.user.id },
      update: {
        monthlyIncome,
        monthlyExpenses,
        creditCardDebt,
        loanDebt,
        overdraftDebt,
      },
      create: {
        userId: session.user.id,
        monthlyIncome,
        monthlyExpenses,
        creditCardDebt,
        loanDebt,
        overdraftDebt,
      }
    })

    return NextResponse.json(financialData)
  } catch (error) {
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}