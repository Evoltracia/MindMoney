'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { FinancialChart } from '@/components/charts/financial-chart'
import { 
  FileText, 
  Download, 
  Calendar,
  TrendingUp,
  DollarSign,
  Target,
  BarChart3
} from 'lucide-react'
import { toast } from 'sonner'
import jsPDF from 'jspdf'
import 'jspdf-autotable'

declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF
  }
}

export default function ReportsPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [financialData, setFinancialData] = useState<any>(null)
  const [transactions, setTransactions] = useState<any[]>([])
  const [challengeData, setChallengeData] = useState<any>(null)

  useEffect(() => {
    if (!session) {
      router.push('/auth')
      return
    }
    
    loadReportData()
  }, [session, router])

  const loadReportData = async () => {
    try {
      const response = await fetch('/api/financial-data')
      if (response.ok) {
        const data = await response.json()
        setFinancialData(data.financialData)
        setTransactions(data.transactions || [])
        setChallengeData(data.challengeProgress)
      }
    } catch (error) {
      toast.error('Erro ao carregar dados')
    } finally {
      setIsLoading(false)
    }
  }

  const generatePDF = () => {
    if (!financialData) return

    const doc = new jsPDF()
    
    // Header
    doc.setFontSize(20)
    doc.text('MindMoney - Relatório Financeiro', 20, 20)
    
    doc.setFontSize(12)
    doc.text(`Cliente: ${session?.user?.name || 'N/A'}`, 20, 35)
    doc.text(`E-mail: ${session?.user?.email || 'N/A'}`, 20, 45)
    doc.text(`Data: ${new Date().toLocaleDateString('pt-BR')}`, 20, 55)

    // Financial Summary
    doc.setFontSize(16)
    doc.text('Resumo Financeiro', 20, 75)
    
    const summaryData = [
      ['Renda Mensal', `R$ ${financialData.monthlyIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`],
      ['Gastos Mensais', `R$ ${financialData.monthlyExpenses.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`],
      ['Total Livre', `R$ ${(financialData.monthlyIncome - financialData.monthlyExpenses).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`],
      ['Cartão de Crédito', `R$ ${financialData.creditCardDebt.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`],
      ['Empréstimos', `R$ ${financialData.loanDebt.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`],
      ['Cheque Especial', `R$ ${financialData.overdraftDebt.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`],
      ['Total Dívidas', `R$ ${(financialData.creditCardDebt + financialData.loanDebt + financialData.overdraftDebt).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`],
    ]

    doc.autoTable({
      startY: 85,
      head: [['Item', 'Valor']],
      body: summaryData,
      theme: 'grid',
      headStyles: { fillColor: [51, 65, 85] },
    })

    // Transactions
    if (transactions.length > 0) {
      doc.setFontSize(16)
      const lastY = (doc as any).lastAutoTable?.finalY || 150
      doc.text('Transações Recentes', 20, lastY + 20)
      
      const transactionData = transactions.slice(0, 10).map(t => [
        new Date(t.date).toLocaleDateString('pt-BR'),
        t.type === 'INCOME' ? 'Receita' : 'Despesa',
        t.description,
        `R$ ${t.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
      ])

      doc.autoTable({
        startY: lastY + 30,
        head: [['Data', 'Tipo', 'Descrição', 'Valor']],
        body: transactionData,
        theme: 'grid',
        headStyles: { fillColor: [51, 65, 85] },
      })
    }

    // Challenge Progress
    if (challengeData) {
      doc.setFontSize(16)
      const lastY = (doc as any).lastAutoTable?.finalY || 200
      doc.text('Desafio 30 Dias', 20, lastY + 20)
      
      const progressPercentage = (challengeData.currentAmount / challengeData.goalAmount) * 100
      const successDays = challengeData.dailyProgress.filter((d: any) => d.status === 'success').length
      
      const challengeInfo = [
        ['Meta de Economia', `R$ ${challengeData.goalAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`],
        ['Valor Atual', `R$ ${challengeData.currentAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`],
        ['Progresso', `${progressPercentage.toFixed(1)}%`],
        ['Dias Bem-sucedidos', `${successDays}/30`],
      ]

      doc.autoTable({
        startY: lastY + 30,
        head: [['Item', 'Valor']],
        body: challengeInfo,
        theme: 'grid',
        headStyles: { fillColor: [51, 65, 85] },
      })
    }

    doc.save(`mindmoney-relatorio-${new Date().toISOString().split('T')[0]}.pdf`)
    toast.success('PDF gerado com sucesso!')
  }

  const generateCSV = () => {
    if (!financialData) return

    const csvData = [
      ['MindMoney - Relatório Financeiro'],
      [''],
      ['Cliente', session?.user?.name || 'N/A'],
      ['E-mail', session?.user?.email || 'N/A'],
      ['Data', new Date().toLocaleDateString('pt-BR')],
      [''],
      ['RESUMO FINANCEIRO'],
      ['Renda Mensal', financialData.monthlyIncome],
      ['Gastos Mensais', financialData.monthlyExpenses],
      ['Total Livre', financialData.monthlyIncome - financialData.monthlyExpenses],
      ['Cartão de Crédito', financialData.creditCardDebt],
      ['Empréstimos', financialData.loanDebt],
      ['Cheque Especial', financialData.overdraftDebt],
      ['Total Dívidas', financialData.creditCardDebt + financialData.loanDebt + financialData.overdraftDebt],
      [''],
      ['TRANSAÇÕES'],
      ['Data', 'Tipo', 'Descrição', 'Valor'],
      ...transactions.map(t => [
        new Date(t.date).toLocaleDateString('pt-BR'),
        t.type === 'INCOME' ? 'Receita' : 'Despesa',
        t.description,
        t.amount
      ])
    ]

    const csvContent = csvData.map(row => row.join(',')).join('\n')
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob)
      link.setAttribute('href', url)
      link.setAttribute('download', `mindmoney-relatorio-${new Date().toISOString().split('T')[0]}.csv`)
      link.style.visibility = 'hidden'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    }
    
    toast.success('CSV gerado com sucesso!')
  }

  const getChartData = () => {
    if (!financialData) return { summary: null, debts: null, challenge: null }

    const totalFree = financialData.monthlyIncome - financialData.monthlyExpenses
    const totalDebt = financialData.creditCardDebt + financialData.loanDebt + financialData.overdraftDebt

    return {
      summary: {
        labels: ['Renda', 'Gastos', 'Total Livre'],
        values: [
          financialData.monthlyIncome,
          financialData.monthlyExpenses,
          Math.max(0, totalFree)
        ],
        colors: ['rgba(34, 197, 94, 0.8)', 'rgba(239, 68, 68, 0.8)', 'rgba(59, 130, 246, 0.8)']
      },
      debts: {
        labels: ['Cartão de Crédito', 'Empréstimos', 'Cheque Especial'],
        values: [
          financialData.creditCardDebt,
          financialData.loanDebt,
          financialData.overdraftDebt
        ],
        colors: ['rgba(239, 68, 68, 0.8)', 'rgba(245, 158, 11, 0.8)', 'rgba(168, 85, 247, 0.8)']
      },
      challenge: challengeData ? {
        labels: ['Economizado', 'Restante'],
        values: [
          challengeData.currentAmount,
          Math.max(0, challengeData.goalAmount - challengeData.currentAmount)
        ],
        colors: ['rgba(34, 197, 94, 0.8)', 'rgba(148, 163, 184, 0.8)']
      } : null
    }
  }

  const calculateStats = () => {
    if (!financialData) {
      return {
        totalFree: 0,
        totalDebt: 0,
        expenseRatio: 0,
        debtToIncomeRatio: 0,
        totalExtraIncome: 0,
        totalExtraExpenses: 0,
        netExtra: 0
      }
    }

    const totalFree = financialData.monthlyIncome - financialData.monthlyExpenses
    const totalDebt = financialData.creditCardDebt + financialData.loanDebt + financialData.overdraftDebt
    const expenseRatio = financialData.monthlyIncome > 0 ? (financialData.monthlyExpenses / financialData.monthlyIncome) * 100 : 0
    const debtToIncomeRatio = financialData.monthlyIncome > 0 ? (totalDebt / financialData.monthlyIncome) * 100 : 0

    const incomeTransactions = transactions.filter(t => t.type === 'INCOME')
    const expenseTransactions = transactions.filter(t => t.type === 'EXPENSE')
    const totalExtraIncome = incomeTransactions.reduce((sum, t) => sum + t.amount, 0)
    const totalExtraExpenses = expenseTransactions.reduce((sum, t) => sum + t.amount, 0)

    return {
      totalFree,
      totalDebt,
      expenseRatio,
      debtToIncomeRatio,
      totalExtraIncome,
      totalExtraExpenses,
      netExtra: totalExtraIncome - totalExtraExpenses
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Carregando relatórios...</div>
      </div>
    )
  }

  if (!financialData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
        <Header showBackButton />
        <div className="pt-24 pb-16 px-4 flex items-center justify-center">
          <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700 p-8 text-center">
            <CardContent>
              <h2 className="text-2xl font-bold text-white mb-4">
                Dados não encontrados
              </h2>
              <p className="text-slate-300 mb-6">
                Você precisa completar a simulação financeira primeiro.
              </p>
              <Button 
                onClick={() => router.push('/simulation')}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Ir para Simulação
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const chartData = getChartData()
  const stats = calculateStats()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <Header showBackButton />
      
      <div className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-8"
          >
            <h1 className="text-4xl font-bold text-white mb-4">
              Relatórios Financeiros
            </h1>
            <p className="text-xl text-slate-300">
              Análise completa da sua situação financeira
            </p>
          </motion.div>

          {/* Export Actions */}
          <div className="flex flex-wrap gap-4 justify-center mb-8">
            <Button
              onClick={generatePDF}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              <FileText className="w-4 h-4 mr-2" />
              Exportar PDF
            </Button>
            <Button
              onClick={generateCSV}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Download className="w-4 h-4 mr-2" />
              Exportar CSV
            </Button>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">% Gastos/Renda</p>
                    <p className={`text-2xl font-bold ${
                      stats.expenseRatio >= 75 ? 'text-red-400' : 
                      stats.expenseRatio >= 50 ? 'text-yellow-400' : 'text-green-400'
                    }`}>
                      {stats.expenseRatio.toFixed(1)}%
                    </p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">% Dívida/Renda</p>
                    <p className={`text-2xl font-bold ${
                      stats.debtToIncomeRatio >= 100 ? 'text-red-400' : 
                      stats.debtToIncomeRatio >= 50 ? 'text-yellow-400' : 'text-green-400'
                    }`}>
                      {stats.debtToIncomeRatio.toFixed(1)}%
                    </p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-red-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Renda Extra</p>
                    <p className="text-2xl font-bold text-green-400">
                      R$ {stats.totalExtraIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <DollarSign className="w-8 h-8 text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Saldo Extra</p>
                    <p className={`text-2xl font-bold ${
                      stats.netExtra >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      R$ {stats.netExtra.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <Target className="w-8 h-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {chartData.summary && (
              <FinancialChart
                title="Resumo Financeiro"
                data={chartData.summary}
                showToggle={true}
              />
            )}
            
            {chartData.debts && (
              <FinancialChart
                title="Distribuição de Dívidas"
                data={chartData.debts}
                showToggle={true}
              />
            )}
          </div>

          {/* Challenge Progress */}
          {chartData.challenge && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
              <FinancialChart
                title="Progresso do Desafio 30 Dias"
                data={chartData.challenge}
                showToggle={true}
              />
              
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Estatísticas do Desafio</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-slate-300">Meta:</span>
                      <span className="text-white font-semibold">
                        R$ {challengeData.goalAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">Economizado:</span>
                      <span className="text-green-400 font-semibold">
                        R$ {challengeData.currentAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">Progresso:</span>
                      <span className="text-blue-400 font-semibold">
                        {((challengeData.currentAmount / challengeData.goalAmount) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">Dias Sucessos:</span>
                      <span className="text-green-400 font-semibold">
                        {challengeData.dailyProgress.filter((d: any) => d.status === 'success').length}/30
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Transactions Table */}
          <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Histórico de Transações</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-slate-600">
                      <th className="text-slate-300 pb-3">Data</th>
                      <th className="text-slate-300 pb-3">Tipo</th>
                      <th className="text-slate-300 pb-3">Descrição</th>
                      <th className="text-slate-300 pb-3 text-right">Valor</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.length > 0 ? (
                      transactions.map((transaction, index) => (
                        <tr key={index} className="border-b border-slate-700">
                          <td className="text-slate-300 py-3">
                            {new Date(transaction.date).toLocaleDateString('pt-BR')}
                          </td>
                          <td className="text-slate-300 py-3">
                            <span className={`px-2 py-1 rounded text-xs ${
                              transaction.type === 'INCOME' 
                                ? 'bg-green-500/20 text-green-400' 
                                : 'bg-red-500/20 text-red-400'
                            }`}>
                              {transaction.type === 'INCOME' ? 'Receita' : 'Despesa'}
                            </span>
                          </td>
                          <td className="text-white py-3">{transaction.description}</td>
                          <td className={`py-3 text-right font-semibold ${
                            transaction.type === 'INCOME' ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {transaction.type === 'INCOME' ? '+' : '-'}R$ {transaction.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={4} className="text-slate-400 text-center py-8">
                          Nenhuma transação encontrada
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Footer />
    </div>
  )
}