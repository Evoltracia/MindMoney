'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { FinancialChart } from '@/components/charts/financial-chart'
import { ChallengeCalendar } from '@/components/challenge/challenge-calendar'
import { 
  Plus, 
  Minus, 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  Target,
  BarChart3
} from 'lucide-react'
import { toast } from 'sonner'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

export default function DashboardPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [financialData, setFinancialData] = useState<any>(null)
  const [transactions, setTransactions] = useState<any[]>([])
  const [challengeData, setChallengeData] = useState<any>(null)
  
  // Transaction form
  const [transactionForm, setTransactionForm] = useState({
    type: 'INCOME',
    amount: '',
    description: ''
  })

  useEffect(() => {
    if (!session) {
      router.push('/auth')
      return
    }
    
    loadDashboardData()
  }, [session, router])

  const loadDashboardData = async () => {
    try {
      const response = await fetch('/api/financial-data')
      if (response.ok) {
        const data = await response.json()
        setFinancialData(data.financialData)
        setTransactions(data.transactions || [])
        setChallengeData(data.challengeProgress)
      }
    } catch (error) {
      toast.error('Erro ao carregar dados')
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddTransaction = async () => {
    if (!transactionForm.amount || !transactionForm.description) {
      toast.error('Preencha todos os campos')
      return
    }

    try {
      const response = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(transactionForm),
      })

      if (response.ok) {
        toast.success('Transação adicionada!')
        setTransactionForm({ type: 'INCOME', amount: '', description: '' })
        loadDashboardData() // Reload data
      }
    } catch (error) {
      toast.error('Erro ao adicionar transação')
    }
  }

  const getFinancialStatus = () => {
    if (!financialData) return { color: 'gray', status: 'Carregando...', icon: BarChart3 }
    
    const totalDebt = financialData.creditCardDebt + financialData.loanDebt + financialData.overdraftDebt
    const totalFree = financialData.monthlyIncome - financialData.monthlyExpenses
    const expenseRatio = financialData.monthlyExpenses / financialData.monthlyIncome

    if (totalDebt > financialData.monthlyIncome) {
      return { 
        color: 'red', 
        status: 'URGENTE - Dívidas excedem renda', 
        icon: AlertTriangle,
        bgColor: 'bg-red-500/20',
        textColor: 'text-red-400'
      }
    }
    
    if (expenseRatio >= 0.75) {
      return { 
        color: 'yellow', 
        status: 'ATENÇÃO - Gastos altos', 
        icon: TrendingDown,
        bgColor: 'bg-yellow-500/20',
        textColor: 'text-yellow-400'
      }
    }
    
    return { 
      color: 'green', 
      status: 'POSITIVO - Situação saudável', 
      icon: TrendingUp,
      bgColor: 'bg-green-500/20',
      textColor: 'text-green-400'
    }
  }

  const getChartData = () => {
    if (!financialData) return { summary: null, debts: null }

    const status = getFinancialStatus()
    const baseColors = {
      red: ['rgba(239, 68, 68, 0.8)', 'rgba(220, 38, 38, 0.8)', 'rgba(185, 28, 28, 0.8)'],
      yellow: ['rgba(245, 158, 11, 0.8)', 'rgba(217, 119, 6, 0.8)', 'rgba(180, 83, 9, 0.8)'],
      green: ['rgba(34, 197, 94, 0.8)', 'rgba(22, 163, 74, 0.8)', 'rgba(21, 128, 61, 0.8)']
    }

    const colors = baseColors[status.color as keyof typeof baseColors] || baseColors.green

    return {
      summary: {
        labels: ['Renda', 'Gastos', 'Total Livre'],
        values: [
          financialData.monthlyIncome,
          financialData.monthlyExpenses,
          Math.max(0, financialData.monthlyIncome - financialData.monthlyExpenses)
        ],
        colors
      },
      debts: {
        labels: ['Cartão de Crédito', 'Empréstimos', 'Cheque Especial'],
        values: [
          financialData.creditCardDebt,
          financialData.loanDebt,
          financialData.overdraftDebt
        ],
        colors: ['rgba(239, 68, 68, 0.8)', 'rgba(245, 158, 11, 0.8)', 'rgba(168, 85, 247, 0.8)']
      }
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Carregando dashboard...</div>
      </div>
    )
  }

  if (!financialData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
        <Header showBackButton />
        <div className="pt-24 pb-16 px-4 flex items-center justify-center">
          <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700 p-8 text-center">
            <CardContent>
              <h2 className="text-2xl font-bold text-white mb-4">
                Dados não encontrados
              </h2>
              <p className="text-slate-300 mb-6">
                Você precisa completar a simulação financeira primeiro.
              </p>
              <Button 
                onClick={() => router.push('/simulation')}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Ir para Simulação
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const status = getFinancialStatus()
  const chartData = getChartData()
  const StatusIcon = status.icon

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <Header showBackButton />
      
      <div className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-8"
          >
            <h1 className="text-4xl font-bold text-white mb-4">
              Dashboard Financeiro
            </h1>
            <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg ${status.bgColor}`}>
              <StatusIcon className={`w-5 h-5 ${status.textColor}`} />
              <span className={`font-semibold ${status.textColor}`}>
                {status.status}
              </span>
            </div>
          </motion.div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Renda Mensal</p>
                    <p className="text-2xl font-bold text-green-400">
                      R$ {financialData.monthlyIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <DollarSign className="w-8 h-8 text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Gastos Mensais</p>
                    <p className="text-2xl font-bold text-red-400">
                      R$ {financialData.monthlyExpenses.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <Minus className="w-8 h-8 text-red-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Total Livre</p>
                    <p className={`text-2xl font-bold ${
                      (financialData.monthlyIncome - financialData.monthlyExpenses) >= 0 
                        ? 'text-green-400' 
                        : 'text-red-400'
                    }`}>
                      R$ {(financialData.monthlyIncome - financialData.monthlyExpenses).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Total Dívidas</p>
                    <p className="text-2xl font-bold text-red-400">
                      R$ {(financialData.creditCardDebt + financialData.loanDebt + financialData.overdraftDebt).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <AlertTriangle className="w-8 h-8 text-red-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {chartData.summary && (
              <FinancialChart
                title="Resumo Financeiro"
                data={chartData.summary}
              />
            )}
            
            {chartData.debts && (
              <FinancialChart
                title="Detalhamento de Dívidas"
                data={chartData.debts}
              />
            )}
          </div>

          {/* Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Ações Rápidas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="w-full bg-green-600 hover:bg-green-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Nova Receita
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-slate-800 border-slate-700">
                    <DialogHeader>
                      <DialogTitle className="text-white">Adicionar Transação</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label className="text-white">Tipo</Label>
                        <Select 
                          value={transactionForm.type} 
                          onValueChange={(value) => setTransactionForm({...transactionForm, type: value})}
                        >
                          <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-700 border-slate-600">
                            <SelectItem value="INCOME">Receita</SelectItem>
                            <SelectItem value="EXPENSE">Despesa</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label className="text-white">Valor (R$)</Label>
                        <Input
                          type="number"
                          placeholder="0.00"
                          className="bg-slate-700 border-slate-600 text-white"
                          value={transactionForm.amount}
                          onChange={(e) => setTransactionForm({...transactionForm, amount: e.target.value})}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label className="text-white">Descrição</Label>
                        <Input
                          placeholder="Descrição da transação"
                          className="bg-slate-700 border-slate-600 text-white"
                          value={transactionForm.description}
                          onChange={(e) => setTransactionForm({...transactionForm, description: e.target.value})}
                        />
                      </div>
                      
                      <Button 
                        onClick={handleAddTransaction}
                        className="w-full bg-blue-600 hover:bg-blue-700"
                      >
                        Adicionar
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <Button 
                  onClick={() => router.push('/reports')}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Ver Relatórios
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Transações Recentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {transactions.length > 0 ? (
                    transactions.slice(0, 5).map((transaction, index) => (
                      <div key={index} className="flex justify-between items-center p-3 bg-slate-700/50 rounded-lg">
                        <div>
                          <p className="text-white font-medium">{transaction.description}</p>
                          <p className="text-slate-400 text-sm">
                            {new Date(transaction.date).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                        <span className={`font-bold ${
                          transaction.type === 'INCOME' ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {transaction.type === 'INCOME' ? '+' : '-'}R$ {transaction.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                    ))
                  ) : (
                    <p className="text-slate-400 text-center py-4">
                      Nenhuma transação encontrada
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Challenge Section */}
          <ChallengeCalendar 
            challengeData={challengeData}
            onUpdate={(data) => setChallengeData(data)}
          />
        </div>
      </div>
      
      <Footer />
    </div>
  )
}