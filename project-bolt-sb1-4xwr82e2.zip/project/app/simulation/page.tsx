'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { DollarSign, CreditCard, Building, Wallet } from 'lucide-react'
import { toast } from 'sonner'

export default function SimulationPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [loadingData, setLoadingData] = useState(true)
  
  const [formData, setFormData] = useState({
    monthlyIncome: '',
    monthlyExpenses: '',
    creditCardDebt: '',
    loanDebt: '',
    overdraftDebt: ''
  })

  const totalFree = parseFloat(formData.monthlyIncome || '0') - parseFloat(formData.monthlyExpenses || '0')
  const totalDebt = parseFloat(formData.creditCardDebt || '0') + parseFloat(formData.loanDebt || '0') + parseFloat(formData.overdraftDebt || '0')

  useEffect(() => {
    if (!session) {
      router.push('/auth')
      return
    }
    
    loadExistingData()
  }, [session, router])

  const loadExistingData = async () => {
    try {
      const response = await fetch('/api/financial-data')
      if (response.ok) {
        const data = await response.json()
        if (data.financialData) {
          setFormData({
            monthlyIncome: data.financialData.monthlyIncome.toString(),
            monthlyExpenses: data.financialData.monthlyExpenses.toString(),
            creditCardDebt: data.financialData.creditCardDebt.toString(),
            loanDebt: data.financialData.loanDebt.toString(),
            overdraftDebt: data.financialData.overdraftDebt.toString(),
          })
        }
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
    } finally {
      setLoadingData(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch('/api/financial-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          monthlyIncome: parseFloat(formData.monthlyIncome),
          monthlyExpenses: parseFloat(formData.monthlyExpenses),
          creditCardDebt: parseFloat(formData.creditCardDebt || '0'),
          loanDebt: parseFloat(formData.loanDebt || '0'),
          overdraftDebt: parseFloat(formData.overdraftDebt || '0'),
        }),
      })

      if (response.ok) {
        toast.success('Dados salvos com sucesso!')
        router.push('/dashboard')
      } else {
        toast.error('Erro ao salvar dados')
      }
    } catch (error) {
      toast.error('Erro ao salvar dados')
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    // Remove caracteres não numéricos exceto vírgula e ponto
    const cleanValue = value.replace(/[^\d.,]/g, '').replace(',', '.')
    setFormData({ ...formData, [field]: cleanValue })
  }

  const formatCurrency = (value: string) => {
    if (!value) return ''
    const num = parseFloat(value)
    if (isNaN(num)) return value
    return num.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
  }

  if (loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Carregando seus dados...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <Header showBackButton />
      
      <div className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-8"
          >
            <h1 className="text-4xl font-bold text-white mb-4">
              Olá, {session?.user?.name || 'usuário'}! 👋
            </h1>
            <p className="text-xl text-slate-300">
              Vamos começar com seus dados financeiros para criar um plano personalizado
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-green-400" />
                    Dados de Renda e Gastos
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-2">
                      <Label className="text-white">Renda Mensal</Label>
                      <Input
                        type="text"
                        placeholder="R$ 0,00"
                        className="bg-slate-700 border-slate-600 text-white"
                        value={formData.monthlyIncome}
                        onChange={(e) => handleInputChange('monthlyIncome', e.target.value)}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-white">Gastos Mensais</Label>
                      <Input
                        type="text"
                        placeholder="R$ 0,00"
                        className="bg-slate-700 border-slate-600 text-white"
                        value={formData.monthlyExpenses}
                        onChange={(e) => handleInputChange('monthlyExpenses', e.target.value)}
                        required
                      />
                    </div>
                    
                    <div className="p-4 bg-slate-700/50 rounded-lg">
                      <div className="flex justify-between items-center">
                        <span className="text-white font-semibold">Total Livre:</span>
                        <span className={`text-xl font-bold ${totalFree >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {formatCurrency(totalFree.toString())}
                        </span>
                      </div>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-red-400" />
                    Suas Dívidas
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-white flex items-center gap-2">
                        <CreditCard className="w-4 h-4" />
                        Cartão de Crédito
                      </Label>
                      <Input
                        type="text"
                        placeholder="R$ 0,00"
                        className="bg-slate-700 border-slate-600 text-white"
                        value={formData.creditCardDebt}
                        onChange={(e) => handleInputChange('creditCardDebt', e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-white flex items-center gap-2">
                        <Building className="w-4 h-4" />
                        Empréstimos
                      </Label>
                      <Input
                        type="text"
                        placeholder="R$ 0,00"
                        className="bg-slate-700 border-slate-600 text-white"
                        value={formData.loanDebt}
                        onChange={(e) => handleInputChange('loanDebt', e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-white flex items-center gap-2">
                        <Wallet className="w-4 h-4" />
                        Cheque Especial
                      </Label>
                      <Input
                        type="text"
                        placeholder="R$ 0,00"
                        className="bg-slate-700 border-slate-600 text-white"
                        value={formData.overdraftDebt}
                        onChange={(e) => handleInputChange('overdraftDebt', e.target.value)}
                      />
                    </div>
                    
                    <div className="p-4 bg-slate-700/50 rounded-lg">
                      <div className="flex justify-between items-center">
                        <span className="text-white font-semibold">Total Dívidas:</span>
                        <span className="text-xl font-bold text-red-400">
                          {formatCurrency(totalDebt.toString())}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="text-center mt-8"
          >
            <Button
              onClick={handleSubmit}
              className="bg-blue-600 hover:bg-blue-700 text-white px-12 py-4 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
              disabled={isLoading}
            >
              {isLoading ? 'Salvando...' : 'Salvar e ver Dashboard'}
            </Button>
          </motion.div>
        </div>
      </div>
      
      <Footer />
    </div>
  )
}