'use client'

import { useState } from 'react'
import { useSession, signOut } from 'next-auth/react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Menu, X, ChevronLeft, LogOut, User, BarChart3 } from 'lucide-react'

interface HeaderProps {
  showBackButton?: boolean
  onBack?: () => void
}

export function Header({ showBackButton, onBack }: HeaderProps) {
  const { data: session } = useSession()
  const router = useRouter()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const handleSignOut = () => {
    signOut({ callbackUrl: '/' })
  }

  const handleBack = () => {
    if (onBack) {
      onBack()
    } else {
      router.back()
    }
  }

  return (
    <header className="bg-slate-900 text-white shadow-lg fixed top-0 left-0 right-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            {showBackButton && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBack}
                className="text-white hover:bg-slate-800"
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Voltar
              </Button>
            )}
            
            <Link href="/" className="flex items-center gap-2">
              <BarChart3 className="w-6 h-6 text-blue-400" />
              <span className="text-xl font-bold">MindMoney</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            {session && (
              <>
                <Link
                  href="/dashboard"
                  className="hover:text-blue-400 transition-colors"
                >
                  Dashboard
                </Link>
                <Link
                  href="/reports"
                  className="hover:text-blue-400 transition-colors"
                >
                  Relatórios
                </Link>
                {session.user.role === 'OWNER' && (
                  <Link
                    href="/admin"
                    className="hover:text-blue-400 transition-colors"
                  >
                    Admin
                  </Link>
                )}
              </>
            )}
          </nav>

          <div className="flex items-center gap-4">
            {session ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={session.user.image || ''} />
                      <AvatarFallback>
                        {session.user.name?.charAt(0)?.toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden md:block">{session.user.name}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>
                    <User className="w-4 h-4 mr-2" />
                    Perfil
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleSignOut}>
                    <LogOut className="w-4 h-4 mr-2" />
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="hidden md:flex gap-2">
                <Button variant="ghost" asChild>
                  <Link href="/auth">Entrar</Link>
                </Button>
                <Button variant="default" asChild>
                  <Link href="/auth">Cadastrar</Link>
                </Button>
              </div>
            )}

            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-slate-700">
            <div className="flex flex-col gap-2 pt-4">
              {session ? (
                <>
                  <Link
                    href="/dashboard"
                    className="block py-2 px-4 hover:bg-slate-800 rounded"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Dashboard
                  </Link>
                  <Link
                    href="/reports"
                    className="block py-2 px-4 hover:bg-slate-800 rounded"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Relatórios
                  </Link>
                  {session.user.role === 'OWNER' && (
                    <Link
                      href="/admin"
                      className="block py-2 px-4 hover:bg-slate-800 rounded"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Admin
                    </Link>
                  )}
                  <button
                    onClick={handleSignOut}
                    className="text-left py-2 px-4 hover:bg-slate-800 rounded"
                  >
                    Sair
                  </button>
                </>
              ) : (
                <>
                  <Link
                    href="/auth"
                    className="block py-2 px-4 hover:bg-slate-800 rounded"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Entrar
                  </Link>
                  <Link
                    href="/auth"
                    className="block py-2 px-4 hover:bg-slate-800 rounded"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Cadastrar
                  </Link>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  )
}