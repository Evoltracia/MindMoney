'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Target, Calendar, TrendingUp } from 'lucide-react'
import { toast } from 'sonner'

interface ChallengeCalendarProps {
  challengeData?: {
    goalAmount: number
    currentAmount: number
    dailyProgress: any[]
    startDate: string
  }
  onUpdate: (data: any) => void
}

export function ChallengeCalendar({ challengeData, onUpdate }: ChallengeCalendarProps) {
  const [goalAmount, setGoalAmount] = useState(challengeData?.goalAmount?.toString() || '')
  const [dailyProgress, setDailyProgress] = useState<any[]>(
    challengeData?.dailyProgress || Array(30).fill({ status: 'pending', amount: 0 })
  )
  const [currentAmount, setCurrentAmount] = useState(challengeData?.currentAmount || 0)
  const [selectedDay, setSelectedDay] = useState<number | null>(null)
  const [dayAmount, setDayAmount] = useState('')

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-500'
      case 'partial': return 'bg-yellow-500'
      case 'failed': return 'bg-red-500'
      default: return 'bg-slate-600'
    }
  }

  const handleDayClick = (dayIndex: number) => {
    setSelectedDay(dayIndex)
    setDayAmount(dailyProgress[dayIndex]?.amount?.toString() || '')
  }

  const handleDayUpdate = async () => {
    if (selectedDay === null) return

    const amount = parseFloat(dayAmount || '0')
    const dailyGoal = parseFloat(goalAmount) / 30
    
    let status = 'pending'
    if (amount >= dailyGoal) status = 'success'
    else if (amount > 0) status = 'partial'
    else status = 'failed'

    const newProgress = [...dailyProgress]
    const oldAmount = newProgress[selectedDay]?.amount || 0
    newProgress[selectedDay] = { status, amount }

    const newCurrentAmount = currentAmount - oldAmount + amount

    setDailyProgress(newProgress)
    setCurrentAmount(newCurrentAmount)

    // Save to database
    try {
      const response = await fetch('/api/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          goalAmount: parseFloat(goalAmount),
          currentAmount: newCurrentAmount,
          dailyProgress: newProgress,
        }),
      })

      if (response.ok) {
        toast.success('Progresso atualizado!')
        onUpdate({ goalAmount: parseFloat(goalAmount), currentAmount: newCurrentAmount, dailyProgress: newProgress })
      }
    } catch (error) {
      toast.error('Erro ao salvar progresso')
    }

    setSelectedDay(null)
    setDayAmount('')
  }

  const handleGoalSave = async () => {
    try {
      const response = await fetch('/api/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          goalAmount: parseFloat(goalAmount),
          currentAmount,
          dailyProgress,
        }),
      })

      if (response.ok) {
        toast.success('Meta salva!')
        onUpdate({ goalAmount: parseFloat(goalAmount), currentAmount, dailyProgress })
      }
    } catch (error) {
      toast.error('Erro ao salvar meta')
    }
  }

  const progressPercentage = goalAmount ? (currentAmount / parseFloat(goalAmount)) * 100 : 0

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Target className="w-5 h-5 text-blue-400" />
            Desafio 30 Dias
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white">Meta de Economia (R$)</Label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="1000.00"
                  className="bg-slate-700 border-slate-600 text-white"
                  value={goalAmount}
                  onChange={(e) => setGoalAmount(e.target.value)}
                />
                <Button onClick={handleGoalSave} className="bg-blue-600 hover:bg-blue-700">
                  Salvar
                </Button>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-white">Progresso Atual</Label>
              <div className="text-2xl font-bold text-green-400">
                R$ {currentAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-sm text-slate-300">
                {progressPercentage.toFixed(1)}% da meta
              </div>
            </div>
          </div>

          <div className="w-full bg-slate-700 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-blue-500 to-green-500 h-3 rounded-full transition-all duration-300"
              style={{ width: `${Math.min(progressPercentage, 100)}%` }}
            />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-400" />
            Calendário de Progresso
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-6 gap-2 mb-4">
            {dailyProgress.map((day, index) => (
              <button
                key={index}
                onClick={() => handleDayClick(index)}
                className={`
                  w-12 h-12 rounded-lg flex items-center justify-center text-white font-semibold
                  transition-all duration-200 hover:scale-105 border-2
                  ${getStatusColor(day.status)}
                  ${selectedDay === index ? 'border-white' : 'border-transparent'}
                `}
              >
                {index + 1}
              </button>
            ))}
          </div>

          {selectedDay !== null && (
            <div className="bg-slate-700/50 p-4 rounded-lg">
              <h4 className="text-white font-semibold mb-2">
                Dia {selectedDay + 1}
              </h4>
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="Valor economizado"
                  className="bg-slate-600 border-slate-500 text-white"
                  value={dayAmount}
                  onChange={(e) => setDayAmount(e.target.value)}
                />
                <Button onClick={handleDayUpdate} className="bg-green-600 hover:bg-green-700">
                  Atualizar
                </Button>
              </div>
            </div>
          )}

          <div className="mt-4 grid grid-cols-3 gap-4 text-center">
            <div className="bg-green-500/20 p-3 rounded-lg">
              <div className="text-green-400 font-bold">
                {dailyProgress.filter(d => d.status === 'success').length}
              </div>
              <div className="text-sm text-slate-300">Sucessos</div>
            </div>
            <div className="bg-yellow-500/20 p-3 rounded-lg">
              <div className="text-yellow-400 font-bold">
                {dailyProgress.filter(d => d.status === 'partial').length}
              </div>
              <div className="text-sm text-slate-300">Parciais</div>
            </div>
            <div className="bg-red-500/20 p-3 rounded-lg">
              <div className="text-red-400 font-bold">
                {dailyProgress.filter(d => d.status === 'failed').length}
              </div>
              <div className="text-sm text-slate-300">Perdidos</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}