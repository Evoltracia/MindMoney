export function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-8 mt-16">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h3 className="text-xl font-bold mb-2">MindMoney</h3>
            <p className="text-slate-400">Seu Comando Financeiro Inteligente</p>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-slate-400">Precisa de ajuda?</p>
            <a 
              href="tel:11981679795" 
              className="text-blue-400 font-semibold text-lg hover:text-blue-300 transition-colors"
            >
              (11) 98167-9795
            </a>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-slate-700 text-center text-slate-400">
          <p>&copy; 2024 MindMoney. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}