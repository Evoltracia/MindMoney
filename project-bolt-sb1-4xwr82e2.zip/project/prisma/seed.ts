import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  const email = 'owner@mindmoney.com'
  const password = 'SenhaFort3#'
  const hashedPassword = await bcrypt.hash(password, 10)
  
  // Check if owner already exists
  const existingOwner = await prisma.user.findUnique({
    where: { email }
  })

  if (existingOwner) {
    console.log('OWNER já existe:', email)
    return
  }

  // Create OWNER user
  const owner = await prisma.user.create({
    data: { 
      name: 'MindMoney Owner', 
      email, 
      phone: '(11) 98167-9795', 
      password: hashedPassword, 
      role: 'OWNER' 
    }
  })
  
  console.log('OWNER criado com sucesso!')
  console.log('Email:', email)
  console.log('Senha:', password)
  console.log('ID:', owner.id)
}

main()
  .catch((e) => {
    console.error('Erro ao criar OWNER:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })